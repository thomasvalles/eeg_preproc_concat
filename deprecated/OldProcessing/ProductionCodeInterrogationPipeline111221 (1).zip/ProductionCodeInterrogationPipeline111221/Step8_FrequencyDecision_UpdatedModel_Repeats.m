clear
clc
close all

%%Set Nearest neighbor pairs
NN_ANT = {
    [34     2    33     5]
    [1     3    34    35]
    [35     2    36     7]
    [37    33    58     9]
    [37    38    41    34]
    [39    38    42    10]
    [40    39    43    35]
    [40    36    59    12]
    [58    41    44    37]
    [41    42    45    38]
    [43    42    46    39]
    [59    43    47    40]
    [60    14    20    24]
    [44    60    58     9]
    [44    45    41    48]
    [32    42    45    46]
    [46    47    43    49]
    [47    59    61    12]
    [61    18    23    28]
    [60    48    44    50]
    [48    32    45    51]
    [49    32    46    52]
    [61    49    47    53]
    [50    62    60    20]
    [50    51    48    54]
    [52    51    29    32]
    [53    52    49    57]
    [53    63    61    23]
    [26    64    56    55]
    [55    54    64    62]
    [56    57    64    63]
    [16    26    22    21]
    [37    34     1     4]
    [ 1     5    38    33]
    [ 3     7    39    36]
    [40    35     3     8]
    [ 4     5    33     9]
    [ 5     6    10    34]
    [ 7     6    11    35]
    [ 8     7    36    12]
    [ 9    10    15     5]
    [16     6    10    11]
    [12    11    17     7]
    [15    14     9    20]
    [21    10    16    15]
    [22    11    17    16]
    [17    18    12    23]
    [20    21    15    25]
    [23    22    17    27]
    [24    25    62    20]
    [25    26    21    55]
    [27    26    22    56]
    [28    27    63    23]
    [62    55    30    25]
    [54    30    25    51]
    [57    31    27    52]
    [63    56    31    27]
    [ 9     4    14    44]
    [12     8    18    47]
    [20    24    14    44]
    [23    28    18    47]
    [54    50    55    30]
    [57    53    56    31]
    [29    31    30    56]};



subjid = '21-125_20210902';
%Load example eeg with same structure. Use this for channel locations
EEG = pop_loadset('/Users/andrewwilson/Documents/EEG/ExampleEEG/TMS20-104_2020-09-21_Merged_FASTER_VI.set');
%dirData = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/' subjid '/Step8_ASCOutput/'];
% %Where to save output mat files
%saveDir = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/' subjid '/Step9_FrequencyOutputDecision/'];

dirData = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/TestFile/SCC-024_20220727/Step8_ASCOutput/'];
%Where to save output mat files
saveDir = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/MethodsAnalysis/Methods56/FinalFilesForJuliane/58Subjects/Output/'];


%go to data directory and get patient IDs for all files in that directory.
cd(dirData)
files = dir('*.mat');
files = {files.name}';
patID = [];
for iFile = 1:numel(files)
    tmpsplit = strsplit(files{iFile}, '_');
    patID{iFile} = tmpsplit{3};
end
nPat = numel(files);

%--------------------------------------------------------------------------

AllPREASC = cell(1,nPat);
AllPOSTASC = cell(1,nPat);
AllStimFreq = cell(1,nPat);
AllChanLabels = cell(64,nPat);

EveryStimFreq = [];
%%Load files in for the subset above.
for iPat = 1:nPat
    load(files{iPat})
    AllPREASC{iPat} = aSCPreAll;
    AllPOSTASC{iPat} = aSCPostAll;
    AllStimFreq{iPat} = allStimFreq;
    AllChanLabels(:,iPat) = chanLabels;
    EveryStimFreq = [EveryStimFreq allStimFreq];
    clear aSCPostAll aSCPreAll allStimFreq chanLabels
end


%--------------------------------------------------------------------------
%% Choosing Channels for analysis

%define variables
AnalysisPRE = cell(1,nPat);
AnalysisPOST = cell(1,nPat);
seedChanIdx = [5];
%indices to remove
idxM1M2 = ismember({EEG.chanlocs.labels}', {'M1', 'M2', 'F3'});

%%Chan to do = 1:64 for all channels; choose channels to analyze
chanToDo = 1:64;
chanToDo(idxM1M2) = [];

%Calculate and store all ASC pre, post for all subjects
EveryDiffASC = [];
for iPat = 1:nPat
    temp_matPre = [];
    temp_matPost = [];
    chan1_counter = 1;
    for iChan1 = seedChanIdx
        for iChan2 = chanToDo
            %account for data structures being i = x; j = x+1;
            if(iChan2 < iChan1)
                temp_matPre(:,:,chan1_counter, iChan2) = AllPREASC{iPat}(:,:,iChan2,iChan1);
                temp_matPost(:,:,chan1_counter, iChan2) = AllPOSTASC{iPat}(:,:,iChan2,iChan1);
            else
                temp_matPre(:,:,chan1_counter, iChan2) = AllPREASC{iPat}(:,:,iChan1,iChan2);
                temp_matPost(:,:,chan1_counter, iChan2) = AllPOSTASC{iPat}(:,:,iChan1,iChan2);
            end
        end
        chan1_counter = chan1_counter + 1;
    end
    
    %reduce dimensions and average for multiple seed channels but keep 3
    %dimensiodfsdns
    AnalysisPRE_NoAveraging{iPat} = squeeze(nanmean(temp_matPre,3));
    AnalysisPOST_NoAveraging{iPat} = squeeze(nanmean(temp_matPost,3));

    %%For later use; Diff ASC
    clear temp_matPost temp_matPre
end


%All
%%%%LOOP THROUGH OLD AND NEW PIPELINES
for iMethod = 1:2
    if(iMethod == 1)
        ChanSet = {{'Fpz'},{'F6'}};
    else
        ChanSet = {{'FC3','AF3'},{'FT8','T8','TP8','CP6','P8'}};
    end
    
    
    %Loop through and find indices of channels
    ChansToUse = {};
    ChanString = '';
    for ilistChans = 1:numel(ChanSet)
        TmpChans = [];
        for j = 1:numel(ChanSet{ilistChans})
            TmpChans(j) = find(ismember({EEG.chanlocs.labels}, ChanSet{ilistChans}{j}));
            ChanString = strcat(ChanString, ChanSet{ilistChans}{j});
            ChanString = strcat(ChanString, ',');
        end
        
        %%%FIND CHANNELS TO SMOOTH%%%
        if(iMethod == 1)
            TmpChans = [TmpChans NN_ANT{TmpChans}];
            ChansToUse{ilistChans} = TmpChans;
        else
            ChansToUse{ilistChans} = TmpChans;
        end
        
    end
    
    %% CORRECTING FOR MAGSTIM ERROR
    AllStimFreq{1}(1) = AllStimFreq{1}(2);
    
    %Set structure for pre and Post data
    AllPostData{iPat,1} = AnalysisPOST_NoAveraging{1};
    AllPreData{iPat,1} = AnalysisPRE_NoAveraging{1};
    
    %Set nan values based on what was removed during VI
    AllPreData{iPat,1}(:,RemovedFreqs{1}',:) = NaN;
    AllPostData{iPat,1}(:,RemovedFreqs{1}',:) = NaN;    
    
    %Set window for averaging. 0.1 to get like frequencies
    window = 0.1;
    UpdatedPre1toPost1_sorted = [];
    
    %%Run on Session 1
    UniqueFreqs = unique(AllStimFreq{1});
    UniqueVals_sorted = nan(numel(UniqueFreqs), 3,size(AllPostData{iPat,1},3));
    
    %%Get Frequencies to Remove
    FrequenciesToUse = zeros(1,numel(AllStimFreq{1}));
    FrequenciesToUse(RemovedFreqs{1}') = 1;
    
    %%%%%Run for all
    for iFreq = 1:numel(UniqueFreqs)
        tmp_freqs = AllStimFreq{1};
        window_avg = find(tmp_freqs >= UniqueFreqs(iFreq) - window & tmp_freqs <= UniqueFreqs(iFreq) + window);
        
        %Set frquencies of interest based on method
        if(iMethod == 1)
            FreqofInterest = find(v_FreqAxis >= UniqueFreqs(iFreq) - 2 & v_FreqAxis <= UniqueFreqs(iFreq) + 2);
        else
            FreqofInterest = find(v_FreqAxis >= 13 & v_FreqAxis <= 17);
        end
        
        %Average over frequencies of interest
        Pre1toPost1 = mean(AllPostData{iPat,1}(FreqofInterest,:,:) - AllPreData{iPat,1}(FreqofInterest,:,:),1);
        %Set uniquevalues
        UniqueVals_sorted(iFreq,:,:) = squeeze(Pre1toPost1(1,window_avg,:));        
    end
    
    
    %Average over channels based on method
    FinalValsPre1toPost1_sorted = [];
    for iSite = 1:numel(ChanSet)
        if(iMethod == 1)
            FinalValsPre1toPost1_sorted(:,:,iSite) = nanmedian(UniqueVals_sorted(:,:,ChansToUse{iSite}),3);
        else
            FinalValsPre1toPost1_sorted(:,:,iSite) = nanmean(UniqueVals_sorted(:,:,ChansToUse{iSite}),3);
        end
    end
    
    %Load b values from regressions
    if(iMethod == 1)
        load('/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/ModelValues/101222_MatchedSCCBeta.mat')
    else
        load('/Users/andrewwilson/Documents/Code/ProductionCodeInterrogationPipeline111221/RegressionValues.mat')
    end
    %Loop through and multiply regression values to matrix
    weighted_vals_sorted = ones(size(FinalValsPre1toPost1_sorted,1),size(FinalValsPre1toPost1_sorted,2))*b(end);
    for iSite = 1:numel(ChanSet)
        weighted_vals_sorted = weighted_vals_sorted + FinalValsPre1toPost1_sorted(:,:,iSite)*b(iSite);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Create boxplots
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if(iMethod == 1)
        gcf3 = figure('Renderer', 'painters', 'Position', [5, 5, 1500, 800]);
    end
    allthree = sum(isnan(weighted_vals_sorted), 2) == 0;
    onlytwo = sum(isnan(weighted_vals_sorted), 2) == 1;
    onlyone = sum(isnan(weighted_vals_sorted), 2) == 2;
    subplot(2, 1, iMethod)
    boxplot(weighted_vals_sorted(allthree, :)', 'positions', UniqueFreqs(allthree), 'labels', UniqueFreqs(allthree), 'colors', 'b', 'Widths', 0.2);
    hold on
    boxplot(weighted_vals_sorted(onlytwo, :)', 'positions', UniqueFreqs(onlytwo), 'labels', UniqueFreqs(onlytwo), 'colors', [1, 0, 0], 'Widths', 0.2);
    scatter(UniqueFreqs(onlyone), weighted_vals_sorted(onlyone, :), 'k', 'filled');
    yline(b(end), 'LineWidth', 0.5)
    xticks(4:0.5:18)
    xticklabels(4:0.5:18)
    if(iMethod == 1)
        title('WEIGHTED: Post - Pre, Matched Method', 'FontSize', 18);
    else
        title('WEIGHTED: Post - Pre, 13-17Hz', 'FontSize', 18);
    end
    
    xlabel('Stim Frequency', 'FontSize', 15);
    ylabel('∆Weighted SCC', 'FontSize', 15);
    axis([3.5,18.5,1.2*min(weighted_vals_sorted,[],'all'),1.2*max(weighted_vals_sorted,[],'all')])
    
    
end
close all;
