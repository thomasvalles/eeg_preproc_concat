clear
clc
close all

subjid = '21-125_20210902';
NN_ANT = {
    [34     2    33     5]
    [1     3    34    35]
    [35     2    36     7]
    [37    33    58     9]
    [37    38    41    34]
    [39    38    42    10]
    [40    39    43    35]
    [40    36    59    12]
    [58    41    44    37]
    [41    42    45    38]
    [43    42    46    39]
    [59    43    47    40]
    [60    14    20    24]
    [44    60    58     9]
    [44    45    41    48]
    [32    42    45    46]
    [46    47    43    49]
    [47    59    61    12]
    [61    18    23    28]
    [60    48    44    50]
    [48    32    45    51]
    [49    32    46    52]
    [61    49    47    53]
    [50    62    60    20]
    [50    51    48    54]
    [52    51    29    32]
    [53    52    49    57]
    [53    63    61    23]
    [26    64    56    55]
    [55    54    64    62]
    [56    57    64    63]
    [16    26    22    21]
    [37    34     1     4]
    [ 1     5    38    33]
    [ 3     7    39    36]
    [40    35     3     8]
    [ 4     5    33     9]
    [ 5     6    10    34]
    [ 7     6    11    35]
    [ 8     7    36    12]
    [ 9    10    15     5]
    [16     6    10    11]
    [12    11    17     7]
    [15    14     9    20]
    [21    10    16    15]
    [22    11    17    16]
    [17    18    12    23]
    [20    21    15    25]
    [23    22    17    27]
    [24    25    62    20]
    [25    26    21    55]
    [27    26    22    56]
    [28    27    63    23]
    [62    55    30    25]
    [54    30    25    51]
    [57    31    27    52]
    [63    56    31    27]
    [ 9     4    14    44]
    [12     8    18    47]
    [20    24    14    44]
    [23    28    18    47]
    [54    50    55    30]
    [57    53    56    31]
    [29    31    30    56]};


%Load example eeg with same structure. Use this for channel locations
EEG = pop_loadset('/Users/andrewwilson/Documents/EEG/ExampleEEG/TMS20-104_2020-09-21_Merged_FASTER_VI.set');
%dirData = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/' subjid '/Step8_ASCOutput/'];
% %Where to save output mat files
%saveDir = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/' subjid '/Step9_FrequencyOutputDecision/'];

dirData = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/SCCPipeline/SCC-024_20220727/Step8_ASCOutput/'];
%Where to save output mat files
saveDir = ['/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/MethodsAnalysis/Methods56/FinalFilesForJuliane/58Subjects/Output/'];


%go to data directory and get patient IDs for all files in that directory.
cd(dirData)
files = dir('*.mat');
files = {files.name}';
patID = [];
for iFile = 1:numel(files)
    tmpsplit = strsplit(files{iFile}, '_');
    patID{iFile} = tmpsplit{3};
end
nPat = numel(files);

%--------------------------------------------------------------------------

AllPREASC = cell(1,nPat);
AllPOSTASC = cell(1,nPat);
AllStimFreq = cell(1,nPat);
AllChanLabels = cell(64,nPat);

EveryStimFreq = [];
%%Load files in for the subset above.
for iPat = 1:nPat
    load(files{iPat})
    AllPREASC{iPat} = aSCPreAll;
    AllPOSTASC{iPat} = aSCPostAll;
    AllStimFreq{iPat} = allStimFreq;
    AllChanLabels(:,iPat) = chanLabels;
    EveryStimFreq = [EveryStimFreq allStimFreq];
    clear aSCPostAll aSCPreAll allStimFreq chanLabels
end


%--------------------------------------------------------------------------
%% Choosing Channels for analysis

%define variables
AnalysisPRE = cell(1,nPat);
AnalysisPOST = cell(1,nPat);
seedChanIdx = [5];
%indices to remove
idxM1M2 = ismember({EEG.chanlocs.labels}', {'M1', 'M2', 'F3'});

%%Chan to do = 1:64 for all channels; choose channels to analyze
chanToDo = 1:64;
chanToDo(idxM1M2) = [];

%Calculate and store all ASC pre, post for all subjects
EveryDiffASC = [];
for iPat = 1:nPat
    temp_matPre = [];
    temp_matPost = [];
    chan1_counter = 1;
    for iChan1 = seedChanIdx
        for iChan2 = chanToDo
            %account for data structures being i = x; j = x+1;
            if(iChan2 < iChan1)
                temp_matPre(:,:,chan1_counter, iChan2) = AllPREASC{iPat}(:,:,iChan2,iChan1);
                temp_matPost(:,:,chan1_counter, iChan2) = AllPOSTASC{iPat}(:,:,iChan2,iChan1);
            else
                temp_matPre(:,:,chan1_counter, iChan2) = AllPREASC{iPat}(:,:,iChan1,iChan2);
                temp_matPost(:,:,chan1_counter, iChan2) = AllPOSTASC{iPat}(:,:,iChan1,iChan2);
            end
        end
        chan1_counter = chan1_counter + 1;
    end
    
    %reduce dimensions and average for multiple seed channels but keep 3
    %dimensiodfsdns
    AnalysisPRE_NoAveraging{iPat} = squeeze(nanmean(temp_matPre,3));
    AnalysisPOST_NoAveraging{iPat} = squeeze(nanmean(temp_matPost,3));
    %         %%UPDATED
    %          AnalysisPRE_NoAveraging{iPat} = squeeze(temp_matPre);
    %          AnalysisPOST_NoAveraging{iPat} = squeeze(temp_matPost);
    
    %reduce to average ASC pre and post
    temp_matPre = nanmean(squeeze(nanmean(temp_matPre,3)),3);
    temp_matPost = nanmean(squeeze(nanmean(temp_matPost,3)),3);
    
    AnalysisPRE{iPat} = temp_matPre;
    AnalysisPOST{iPat} = temp_matPost;
    
    %%For later use; Diff ASC
    EveryDiffASC = [EveryDiffASC AnalysisPOST{iPat}-AnalysisPRE{iPat}];
    clear temp_matPost temp_matPre
end

%All
%ChanSet = {{'FC3','AF3'},{'FT8','T8','TP8','CP6','P8'}};
ChanSet = {{'Fpz'},{'F6'}};

%ChanSet = {{'C3'}};

ChansToUse = {};
ChanString = '';
for ilistChans = 1:numel(ChanSet)
    TmpChans = [];
    for j = 1:numel(ChanSet{ilistChans})
        TmpChans(j) = find(ismember({EEG.chanlocs.labels}, ChanSet{ilistChans}{j}));
        ChanString = strcat(ChanString, ChanSet{ilistChans}{j});
        ChanString = strcat(ChanString, ',');
    end
    
    %%%FIND CHANNELS TO SMOOTH%%%
    TmpChans = [TmpChans NN_ANT{TmpChans}];
    ChansToUse{ilistChans} = TmpChans;
end


AllPostData{iPat,1} = AnalysisPOST_NoAveraging{1};
AllPreData{iPat,1} = AnalysisPRE_NoAveraging{1};


window = 0.25;
UpdatedPre1toPost1 = [];
UpdatedPre10toPost10 = [];
%         UpdatedPre1toPost1_local = [];
%         UpdatedPre1toPost1_RightTP = [];
%         UpdatedPre10toPost10_local = [];
%         UpdatedPre10toPost10_RightTP = [];
%%Run on Session 1
for iFreq = 1:numel(AllStimFreq{1})
    tmp_freqs = AllStimFreq{1};
    window_avg = find(tmp_freqs >= tmp_freqs(iFreq) - window & tmp_freqs <= tmp_freqs(iFreq) + window);
    FreqofInterest = find(v_FreqAxis >= tmp_freqs(iFreq) - 2 & v_FreqAxis <= tmp_freqs(iFreq) + 2);
    %FreqofInterest = find(v_FreqAxis >= Frequency(1,iSubj)-2 & v_FreqAxis <= Frequency(1,iSubj)+2);
    
    for iSite = 1:size(AllPostData{iPat,1},3)
        Pre1toPost1{iSite,1} = mean(AllPostData{iPat,1}(FreqofInterest,:,iSite) - AllPreData{iPat,1}(FreqofInterest,:,iSite),1);
        UpdatedPre1toPost1(iSite,iFreq) = nanmedian(Pre1toPost1{iSite,1}(1,window_avg));
    end
end


FinalPre1toPost1 = [];
for iSite = 1:numel(ChanSet)
    FinalPre1toPost1(iSite,:) = median(UpdatedPre1toPost1(ChansToUse{iSite},:));
end


load('/Users/andrewwilson/Documents/EEG/TMSEEG/InterrogationProtocol/ModelValues/101222_MatchedSCCBeta.mat')

weighted_diag = ones(1,size(FinalPre1toPost1,2))*b(end);
for iSite = 1:numel(ChanSet)
    weighted_diag = weighted_diag + FinalPre1toPost1(iSite,:)*b(iSite);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating new MeanDiags with weights
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%figure;
freqTopPeak = [];
rank = [];

[sortedVals, idx_s] = sort(weighted_diag, 'desc');
sortedStim = AllStimFreq{iPat}(idx_s);

[y,x] = findpeaks(weighted_diag, 'MinPeakHeight',-1);
[~, idxSorted]= sort(y, 'descend');
idxTopPeak = x(idxSorted);
freqTopPeak(iPat) = AllStimFreq{iPat}(idxTopPeak(1));


%%Individual plots AverageInertia vs RankAVerage
num_items = 15;
colors = [];
top_freqs = [];
closest = [];
for iPat = 1:nPat
    hFig = figure('units', 'normalized', 'position', [0 0 1 0.5], 'color', 'w');
    
    
    %find peak
    [y,x] = findpeaks(weighted_diag, 'MinPeakHeight',-1);
    [~, idxSorted]= sort(y, 'descend');
    idxTopPeak = x(idxSorted);
    
    temp_stim = sortedStim(1,1:num_items);
    
    %%KMeans Clustering 1D
    idx_k = {};
    C_k = {};
    average_inertia = {};
    av = [];
    average_rank = {};
    allowed_dist = 0.51;
    for iCluster = 1
        rng('default')
        rng(1); % For reproducibility
        [idx_k{iCluster},C_k{iCluster}] = kmeans(temp_stim',iCluster);
        temp_iCluster = NaN;
        for clust = 1:iCluster
            idx_i = find(idx_k{iCluster} == clust);
            
            freqs = temp_stim(idx_i);
            [sortedFreqs,s] = sort(freqs);
            distances = abs(sortedFreqs(1,1:end-1) - sortedFreqs(1,2:end));
            
            if(numel(freqs) > 3 && numel(find(distances > allowed_dist)))
                idx_k{iCluster}(idx_i) = NaN;
                new_freqs = [];
                flag = 0;
                count_1 = 1;
                count_2 = 1;
                for iFreq = 1:numel(sortedFreqs)-1
                    if(sortedFreqs(iFreq+1) - sortedFreqs(iFreq) < allowed_dist)
                        new_freqs{count_1}(1,count_2) = sortedFreqs(iFreq);
                        new_freqs{count_1}(2,count_2) = s(iFreq);
                        new_freqs{count_1}(1,count_2+1) = sortedFreqs(iFreq+1);
                        new_freqs{count_1}(2,count_2+1) = s(iFreq+1);
                        count_2 = count_2 + 1;
                    else
                        if(numel(new_freqs) ~= 0)
                            count_1 = count_1 + 1;
                            count_2 = 1;
                        end
                        
                    end
                end
                if(isnan(max(idx_k{iCluster})))
                    temp_iCluster = 0;
                else
                    temp_iCluster = max(idx_k{iCluster});
                end
                if(numel(new_freqs) == 1)
                    stop = 1;
                    for iClust = 1:stop
                        temp_iCluster = temp_iCluster + 1;
                        for jClust = 1:size(new_freqs{iClust},2)
                            idx_k{iCluster}(idx_i(new_freqs{iClust}(2,jClust))) = clust;
                            disp('');
                        end
                    end
                else
                    stop = numel(new_freqs)
                    for iClust = 1:stop
                        temp_iCluster = temp_iCluster + 1;
                        for jClust = 1:size(new_freqs{iClust},2)
                            idx_k{iCluster}(idx_i(new_freqs{iClust}(2,jClust))) = temp_iCluster;
                        end
                    end
                end
            end
        end
        
        %%Using Inertia for color KMeans
        inertia = zeros(max(idx_k{iCluster}),4);
        clusterToKeep{iCluster} = [];
        
        steps_with_nan = unique(idx_k{iCluster});
        steps = steps_with_nan(~isnan(steps_with_nan));
        for i=1:numel(steps)
            idx_i = find(idx_k{iCluster} == steps(i));
            C_k{iCluster}(steps(i)) = median(temp_stim(idx_i)); %mean(temp_stim(idx_i));%median(temp_stim(idx_i));%
            freqs = temp_stim(idx_i);
            
            [sortedFreqs,s] = sort(freqs);
            distances = abs(sortedFreqs(1,1:end-1) - sortedFreqs(1,2:end));
            
            %If only one value, then remove
            if(numel(freqs) < 3)
                disp(['REMOVE CLUSTER ' num2str(i)]);
                inertia(steps(i),1) = NaN;
                inertia(steps(i),2) = NaN;
                inertia(steps(i),3) = NaN;
                C_k{iCluster}(steps(i)) = NaN;
            elseif(min(distances) > allowed_dist)
                disp(['REMOVE CLUSTER ' num2str(i)]);
                inertia(steps(i),1) = NaN;
                inertia(steps(i),2) = NaN;
                inertia(steps(i),3) = NaN;
                C_k{iCluster}(steps(i)) = NaN;
            else
                clusterToKeep{iCluster}(1,size(clusterToKeep{iCluster},2)+1) = i;
                clusterToKeep{iCluster}(2,size(clusterToKeep{iCluster},2)) = steps(i);
                for j = 1:numel(idx_i)
                    %disp(temp_stim(idx_i(j)));
                    inertia(steps(i),1) = inertia(steps(i),1) + abs(temp_stim(idx_i(j)) - C_k{iCluster}(steps(i)));
                    inertia(steps(i),3) = inertia(steps(i),3) + idx_i(j);
                end
                inertia(steps(i),2) = numel(idx_i);
            end
        end
        
        inertia(clusterToKeep{iCluster}(1,:),4) = inertia(clusterToKeep{iCluster}(1,:),1)./inertia(clusterToKeep{iCluster}(1,:),2);
        
        av(iCluster,1) = mean(inertia(clusterToKeep{iCluster}(1,:),1)./inertia(clusterToKeep{iCluster}(1,:),2));
        average_inertia{iCluster} = inertia(:,1)./inertia(:,2);
        average_rank{iCluster} = inertia(:,3)./inertia(:,2);
        
    end
    idx_nonzero = find(av(:,1) ~= 0);
    NClusters = 1;%min(find(av(:) == min(av(idx_nonzero))));
    average_inertia = average_inertia{NClusters};
    average_rank = average_rank{NClusters};
    idx_k = idx_k{NClusters};
    idx_keep_k = find(sum(idx_k == clusterToKeep{NClusters}(2,:),2));
    idx_k = idx_k(idx_keep_k);
    Clusters = unique(idx_k);
    
    temp_stim = temp_stim(idx_keep_k');
    
    C_k = C_k{NClusters};
    
    %%Plot 1: Plotting spectrum
    s1 = subplot(1, 3, 1);
    %title(['Peak Conn.: ' num2str(freqTopPeak(iPat))], 'FontSize', 16)
    plot(AllStimFreq{iPat},weighted_diag, 'linewidth', 2);
    hold on;
    plot(freqTopPeak(iPat), weighted_diag(idxTopPeak(1)), '.', 'Markersize', 30);
    ylim([-30 70]);
    
    %%Plot 2: Plotting Dots
    subplot(1, 3, 2);
    hold on;
    [idx_c, colorsort] = sort(average_inertia, 'asc');
    cmap = parula(max(idx_k));
    cmap_items = jet(num_items);
    colormap jet
    legend_text = {};
    
    %%PLOT KMEANS CLUSTERS
    colors = [];
    for i=1:numel(Clusters)
        %scatter(iPat,C(i), 100);
        idx_i = find(idx_k == Clusters(i));
        colorspot = find(Clusters(i) == colorsort);
        
        colors(i,:) = cmap(colorspot,:);
        h(i) = scatter(ones(1,numel(idx_i)), temp_stim(idx_i),80, 'filled', 'MarkerFaceColor', cmap(colorspot,:));
        %scatter(iPat, temp_stim(idx_i(j,1)),40, 'filled', 'MarkerFaceColor', cmap(idx_i(j,1),:));
        legend_text{i} = [num2str(C_k(Clusters(i))) ' N=' num2str(numel(idx_i))];
        
        for j = 1:numel(idx_i)
            if(idx_i(j,1) == 1)
                title([patID{iPat} ' Top Ranked Frequency: ' num2str(temp_stim(idx_i(j,1))) 'Hz'], 'FontSize', 16);
            end
            scatter(1.1, temp_stim(idx_i(j,1)),50, 'filled', 'MarkerFaceColor', cmap_items(idx_i(j,1),:));
        end
    end
    %Plot all original
    tmp_stim_plot = sortedStim(1,1:num_items);
    scatter(1.05*ones(1,numel(tmp_stim_plot)), tmp_stim_plot,50, 'x');
    xticks([1 1.05 1.1])
    xticklabels({'Final Clust.','Top 15 Freqs','Rank'})
    xtickangle(45)
    
    %xlabel('Subject', 'FontSize', 16);
    ylabel('Frequency', 'FontSize', 16);
    xlim([0.9 1.2]);
    for i=1:numel(Clusters)
        scatter(1,C_k(Clusters(i)), 100, 'MarkerEdgeColor', 'k');
    end
    legend(h(1:numel(Clusters)),legend_text);
    ylim([0 20]);
    colorbar;
    
    %%Plot 3: Average Inertia vs Rank
    subplot(1, 3, 3);
    hold on;
    
    min_dtz = 1000000;
    min_idx = 0;
    
    for i = 1:numel(Clusters)
        plot([numel(idx_k) - inertia(Clusters(i),2)],average_rank(Clusters(i)), '.','MarkerSize',50, 'color',colors(i,:) );%,100, 'filled', 'MarkerFaceColor', colors(i,:));
        
        grid on;
        p12 = average_rank(Clusters(i));
        p13 = num_items - inertia(Clusters(i),2);
        p22 = 0;
        p23 = 0;
        if(sqrt((p22-p12)^2 + (p23-p13)^2) < min_dtz)
            min_idx = Clusters(i);
            min_dtz = sqrt( (p22-p12)^2 + (p23-p13)^2);
        end
    end
    xlabel('Total Items - Number in Cluster', 'FontSize', 16)
    ylabel('Av. Rank', 'FontSize', 16)
    legend(legend_text);
    title(['Closest to Zero = ' num2str(C_k(min_idx))], 'FontSize', 16);
    
    %Plot Vertical line on subplot 1 with "closest value"
    axes(s1)
    title(['Peak Conn.: ' num2str(freqTopPeak(iPat)) 'Hz'], 'FontSize', 16)
    plot([C_k(min_idx) C_k(min_idx)],[min(weighted_diag) max(weighted_diag)], 'linewidth', 1.5, 'color', 'r');
    xlabel('Stimulation Frequency', 'FontSize', 16);
    ylabel('Weighted Conn. Value', 'FontSize', 16);
    saveas(gcf, [saveDir patID{iPat} '_FreqDecisionMedian.png']);
end
close all;
